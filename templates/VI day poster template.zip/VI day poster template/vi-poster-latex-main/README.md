# vi-poster-latex
LaTeX document class for poster for the Visual Intelligence Days 2021 conference
